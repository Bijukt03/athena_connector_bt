import tableau
import tableauserverclient as TSC
from tableau.dataconnector import Connector, TableDefinition, ColumnDefinition, Schema, DataType
import boto3
from botocore.exceptions import ClientError
import logging
import os
from dotenv import load_dotenv

load_dotenv()

class AthenaConnectionBuilder(tableau.dataconnector.ConnectionBuilder):
    def __init__(self, connection: tableau.dataconnector.Connection):
        self._connection = connection

    def build(self):
        connectionData = self._connection.connectionData

        # Retrieve the credentials from AWS STS
        try:
            sts_client = boto3.client('sts')
            assumed_role_object = sts_client.assume_role(RoleArn=connectionData["roleArn"], RoleSessionName="AssumeRoleSession1")
            credentials = assumed_role_object['Credentials']
        except ClientError as e:
            logging.error(e)
            raise ValueError("Failed to retrieve credentials from STS.")

        # Set the AWS environment variables to use the temporary credentials
        os.environ["AWS_ACCESS_KEY_ID"] = credentials['AccessKeyId']
        os.environ["AWS_SECRET_ACCESS_KEY"] = credentials['SecretAccessKey']
        os.environ["AWS_SESSION_TOKEN"] = credentials['SessionToken']

        # Create the Athena client
        try:
            client = boto3.client('athena', region_name=connectionData["region"])
        except ClientError as e:
            logging.error(e)
            raise ValueError("Failed to create Athena client.")

        # Get the list of available databases
        try:
            response = client.list_databases()
        except ClientError as e:
            logging.error(e)
            raise ValueError("Failed to list Athena databases.")

        # Build the schema
        schema = Schema()
        for database in response['DatabaseList']:
            database_name = database['Name']
            schema.addTable(self.buildTableDefinition(database_name))

        return schema

    def buildTableDefinition(self, databaseName):
        tableDef = TableDefinition()
        tableDef.TableName = databaseName
        tableDef.Columns.Add(ColumnDefinition('column1', DataType.String))
        tableDef.Columns.Add(ColumnDefinition('column2', DataType.Float))
        # Add additional columns as needed
        return tableDef

Connector.registerConnector(AthenaConnectionBuilder)
