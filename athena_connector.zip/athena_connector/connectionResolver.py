class ConnectionResolver:
    @staticmethod
    def resolve_connection(attrs, options):
        resolved = attrs.copy()
        resolved["jdbcurl"] = f"jdbc:awsathena://{resolved['hostname']}:443/"
        resolved["jdbcproperties"] = f"config/jdbc.properties"
        return resolved
