(function propertiesbuilder(attr) {
  var props = {};

  props["aws.region"] = attr["region"];
  props["aws.s3OutputLocation"] = attr["s3_output_location"];
  props["DriverClass"] = "com.simba.athena.jdbc.Driver";

  return props;
})
