import os
import boto3
import base64
import json
from botocore.exceptions import NoCredentialsError

def assume_role(role_arn, session_name):
    sts_client = boto3.client("sts")
    assumed_role_object = sts_client.assume_role(
        RoleArn=role_arn,
        RoleSessionName=session_name
    )
    return assumed_role_object["Credentials"]

def get_credentials(role_arn, session_name):
    try:
        credentials = assume_role(role_arn, session_name)
        return credentials
    except NoCredentialsError:
        raise Exception("Unable to assume the specified IAM role")

def aws_account_check(role_arn, account_name):
    account_id = role_arn.split(":")[4]
    sts_client = boto3.client("sts")
    response = sts_client.get_caller_identity()
    caller_account_id = response["Account"]

    if caller_account_id != account_id:
        raise Exception(f"The specified IAM role ARN belongs to a different AWS account than {account_name}")

def sign_in(auth_data):
    auth_data_dict = json.loads(auth_data)
    connection_helper = json.loads(auth_data_dict["connectionHelperJson"])
    role_arn = connection_helper["roleArn"]
    session_name = connection_helper["sessionName"]
    account_name = connection_helper["accountName"]

    aws_account_check(role_arn, account_name)

    credentials = get_credentials(role_arn, session_name)

    auth_dict = {
        "AccessKeyId": credentials["AccessKeyId"],
        "SecretAccessKey": credentials["SecretAccessKey"],
        "SessionToken": credentials["SessionToken"]
    }
    return json.dumps(auth_dict)
