(function propertiesbuilder(attr) {
  var props = {};

  props["DRIVER"] = "com.simba.athena.jdbc.Driver";
  props["AwsRegion"] = attr["region"];
  props["S3OutputLocation"] = attr["s3_output_location"];

  return props;
})
